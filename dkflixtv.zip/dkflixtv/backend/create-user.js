const bcrypt = require('bcrypt');
const db = require('./db');

const email = 'cliente@teste.com';
const senha = '123456';
const link = 'http://seu-link-m3u.com/cliente';
const validade = '2025-06-01';

bcrypt.hash(senha, 10, (err, hash) => {
  db.run('INSERT INTO users (email, password, link, validade) VALUES (?, ?, ?, ?)',
    [email, hash, link, validade],
    () => {
      console.log('Usuário criado!');
      process.exit();
    });
});
