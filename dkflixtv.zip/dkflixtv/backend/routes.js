const express = require('express');
const db = require('./db');
const bcrypt = require('bcrypt');
const router = express.Router();

router.post('/login', (req, res) => {
  const { email, password } = req.body;
  db.get('SELECT * FROM users WHERE email = ?', [email], (err, user) => {
    if (err || !user) return res.status(401).json({ error: 'Usuário inválido' });

    bcrypt.compare(password, user.password, (err, same) => {
      if (!same) return res.status(401).json({ error: 'Senha incorreta' });

      res.json({
        email: user.email,
        link: user.link,
        validade: user.validade,
      });
    });
  });
});

module.exports = router;
